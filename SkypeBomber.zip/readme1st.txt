== Skype Bomber Version 1.0 ==
== Readme File ==

This file contains information about the software "Skype Bomber", you must accept the terms and conditions to use the software.

** DISCLAIMER **
This software is for educational proporses only, the author, is not responsable for damages, caused for use of this program.


** LICENSE **
This project ir released under the MIT License, see LICENSE.TXT for more details.


** INSTALLATION **
This program is portable, just run "SkypeBomber.exe" to run it.


**  CONTENTS **
The .ZIP folder contains:
	
	/ root
	|
	|
	|---> license.txt (Copy of MIT License)
	|---> readme1st.txt (This file)
	|
	|--- bin/
	|	|
	|	|---> Skypebomber.exe (the program)
	|
	|--- icons/
	|	|
	|	|---> icon.ico (32X32 Windows icon)
	|	|---> icon.jpg (97X97 jpeg icon)
	|
	|--- screenshot/
	|	|
	|	|---> screenshot.jpg (screenshot of skypebomber window)
	|
	|-- source/ (visual basic 6.0 source code)
	|	|
	|	|---> SkypeBomber.vbw
	|	|---> SkypeBomber.vbp
	|	|---> MSSCPRJ.SCC
	|	|---> frmBomber.frm
	|	|---> frmBomber.frx
	_